import { Component, OnInit, OnDestroy, ViewChild, AfterViewInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { MatSelect } from '@angular/material';
import { ReplaySubject, Subject } from 'rxjs';
import { take, takeUntil } from 'rxjs/operators';
import { MatFormFieldModule, MatSelectModule } from '@angular/material';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { RestService } from '../rest.service'

interface Device {
  name: String;
}

interface Model {
  namee: String;
}

interface Issue {
  nameee: String;
}

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  // form;
  HomeForm: FormGroup;
  // items = []
  // items_m = []

  device: Device[] = [{ name: 'Laptop' }, { name: 'Mobile' }];
  issue: Issue[] = [{ nameee: 'Lap1' }, { nameee: 'Mob1' }];
  model: Model[] = [{ namee: 'Lap' }, { namee: 'Mob' }];

  // global = 'Device';

  filtereddevice: Observable<Device[]>;
  filteredmodel: Observable<Model[]>;
  filteredissue: Observable<Issue[]>;

  Devices = new FormControl('');
  Models = new FormControl('');
  Issues = new FormControl('');
  Address1 = new FormControl();
  Address2 = new FormControl();
  constructor(private restservice: RestService, private fb: FormBuilder, ) {

    this.HomeForm = this.fb.group({
      Devices: [null],
      Models: [null],
      Issues: [null]
    });

    this.filtereddevice = this.HomeForm.get('Devices').valueChanges
      .pipe(
        startWith(''),
        map(stated => this._filterDevice(stated))
      );
    this.filteredmodel = this.HomeForm.get('Models').valueChanges
      .pipe(
        startWith(''),
        map(statem =>  this._filterModel(statem))
      )
    this.filteredissue = this.HomeForm.get('Issues').valueChanges
      .pipe(
        startWith(''),
        map(statei =>  this._filterIssue(statei))
      )



    //Get models and issues:

    // const models: any = { "device": "Laptop" }
    // this.restservice.GetIssues(models).subscribe(response => {

    //   for (let entry of response.issues.model) {
    //     var inner_entry = { nameee: entry }

    //     this.issue.push(inner_entry); // 1, "string", false
    //   }
    //   var cut = "";
    //   for (let entry of response.models) {
    //     if (entry != ',') {
    //       cut = cut + entry
    //     }
    //     else {
    //       let inner_entry = { namee: cut }
    //       this.model.push(inner_entry);
    //       cut = ""; // 1, "string", false

    //     }
    //   }
    //   console.log(this.issue)

    // })


  }

  ngOnInit() {

  }

  private _filterDevice(value: any): Device[] {

    const filterValueD = value.toLowerCase();
    return this.device.filter(stated => stated.name.toLowerCase().indexOf(filterValueD) === 0);
  }
  private _filterModel(value: any): Model[] {
    // this.global = 'Model'
    const filterValueM = value.toLowerCase();
    return this.model.filter(statem => statem.namee.toLowerCase().indexOf(filterValueM) === 0);
  }
  private _filterIssue(value: any): Issue[] {
    // this.global = 'Issue'
    // console.log(this.global)
    const filterValueI = value.toLowerCase();
    return this.issue.filter(statei => statei.nameee.toLowerCase().indexOf(filterValueI) === 0);
  }

  // DeviceSelected(event:any){
  //   const _src =event.option.value;
  //   this.device = _src;
  // }

  // getDevice(dev: Device){
  //   return dev['name'];
  // }


//   Modelselected(event:any){
//     const _src =event.option.value;
//     this.model = _src;
//   }

//   getModel(dev: Model){
//     return dev['namee'];
//   }

//   IssueSelected(event:any){
//     const _src =event.option.value;
//     this.device = _src;
//   }

//   getIssue(dev: Issue){
//     return dev['nameee'];
//   }
// }

}
