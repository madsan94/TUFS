export interface Mobile {
    models: string;
    issues: string;
}