export interface Model{
    device:String;
}