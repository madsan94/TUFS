export interface order{
    type:String,
    device:String,
    price:String,
    issue:String
}